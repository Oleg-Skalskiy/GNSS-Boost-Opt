#!/system/bin/sh

# Service controller script

settings put global assisted_gps_enabled 1
settings put global enable_gnss_raw_meas_full_tracking 0
settings put global ntp_server ntp1.vniiftri.ru
settings put global ntp_server_2 ntp2.vniiftri.ru
settings put global ntp_server_3 ntp3.vniiftri.ru
settings put global ntp_server_4 ntp4.vniiftri.ru
