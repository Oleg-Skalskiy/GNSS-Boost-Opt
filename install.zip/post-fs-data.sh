#!/system/bin/sh

# Post Fs controller script

mount -o bind $MODPATH/system/vendor/odm/etc/gps.conf $ORIGDIR/odm/etc/gps.conf
mount -o bind $MODPATH/system/vendor/odm/etc/gps_debug.conf $ORIGDIR/odm/etc/gps_debug.conf
mount -o bind $MODPATH/system/vendor/odm/etc/izat.conf $ORIGDIR/odm/etc/izat.conf
mount -o bind $MODPATH/system/vendor/odm/etc/izat_device.conf $ORIGDIR/odm/etc/izat_device.conf
mount -o bind $MODPATH/system/vendor/odm/etc/flp.conf $ORIGDIR/odm/etc/flp.conf
mount -o bind $MODPATH/system/vendor/odm/etc/lowi.conf $ORIGDIR/odm/etc/lowi.conf
mount -o bind $MODPATH/system/vendor/odm/etc/sap.conf $ORIGDIR/odm/etc/sap.conf
mount -o bind $MODPATH/system/vendor/odm/etc/xtwifi.conf $ORIGDIR/odm/etc/xtwifi.conf

mount -o bind $MODPATH/system/my_product/etc/gps.conf $ORIGDIR/my_product/etc/gps.conf
mount -o bind $MODPATH/system/my_product/etc/gps_debug.conf $ORIGDIR/my_product/etc/gps_debug.conf
mount -o bind $MODPATH/system/my_product/etc/izat.conf $ORIGDIR/my_product/etc/izat.conf
mount -o bind $MODPATH/system/my_product/etc/izat_device.conf $ORIGDIR/my_product/etc/izat_device.conf
mount -o bind $MODPATH/system/my_product/etc/flp.conf $ORIGDIR/my_product/etc/flp.conf
mount -o bind $MODPATH/system/my_product/etc/lowi.conf $ORIGDIR/my_product/etc/lowi.conf
mount -o bind $MODPATH/system/my_product/etc/sap.conf $ORIGDIR/my_product/etc/sap.conf
mount -o bind $MODPATH/system/my_product/etc/xtwifi.conf $ORIGDIR/my_product/etc/xtwifi.conf
