### GNSS Boost&Opt v1.2 - 01.07.2024

* Improved GNSS stability Fixed
		* Fix Server to Select (Russia or Global)
		* Add New Parametrs for Speed & Stability
		* Updated NTP for Russia and Global
		* Off MIUI/HyperOS optimization
		* Fixed satellite connection error
		* Removed SUPL C2K parameters
		* Fixed offline data retrieval
* General
		* Fix Code
		* Fix Some Error
		* Fix Stability System
		* Minor edits
		* Updated base module file MMT (Thanks Zackptg5)

