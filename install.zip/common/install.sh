
umount $MODPATH/system/vendor/odm/etc/gps.conf
umount $MODPATH/system/vendor/odm/etc/gps_debug.conf
umount $MODPATH/system/vendor/odm/etc/izat.conf
umount $MODPATH/system/vendor/odm/etc/izat_device.conf
umount $MODPATH/system/vendor/odm/etc/flp.conf
umount $MODPATH/system/vendor/odm/etc/lowi.conf
umount $MODPATH/system/vendor/odm/etc/sap.conf
umount $MODPATH/system/vendor/odm/etc/xtwifi.conf

umount $MODPATH/system/my_product/etc/gps.conf
umount $MODPATH/system//my_product/etc/gps_debug.conf
umount $MODPATH/system/my_product/etc/izat.conf
umount $MODPATH/system//my_product/etc/izat_device.conf
umount $MODPATH/system//my_product/etc/flp.conf
umount $MODPATH/system//my_product/etc/lowi.conf
umount $MODPATH/system//my_product/etc/sap.conf
umount $MODPATH/system//my_product/etc/xtwifi.conf

GPSCFG="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "gps*.conf") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "izat*.conf") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "flp*.conf") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "lowi*.conf") | $(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "xtwifi*.conf")"
GPSCFG2="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "sap*.conf")"

mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

cp_ch /odm/etc/gps.conf $MODPATH/system/vendor/odm/etc/gps.conf
cp_ch /odm/etc/gps_debug.conf $MODPATH/system/vendor/odm/etc/gps_debug.conf
cp_ch /my_product/etc/gps.conf $MODPATH/system/my_product/etc/gps.conf
cp_ch /my_product/etc/gps_debug.conf $MODPATH/system/my_product/etc/gps_debug.conf
cp_ch /odm/etc/izat.conf $MODPATH/system/vendor/odm/etc/izat.conf
cp_ch /odm/etc/izat_device.conf $MODPATH/system/vendor/odm/etc/izat_device.conf
cp_ch /odm/etc/flp.conf $MODPATH/system/vendor/odm/etc/flp.conf
cp_ch /odm/etc/lowi.conf $MODPATH/system/vendor/odm/etc/lowi.conf
cp_ch /odm/etc/sap.conf $MODPATH/system/vendor/odm/etc/sap.conf
cp_ch /odm/etc/xtwifi.conf $MODPATH/system/vendor/odm/etc/xtwifi.conf
cp_ch /my_product/etc/izat.conf $MODPATH/system/my_product/etc/izat.conf
cp_ch /my_product/etc/izat_device.conf $MODPATH/system/my_product/etc/izat_device.conf
cp_ch /my_product/etc/flp.conf $MODPATH/system/my_product/etc/flp.conf
cp_ch /my_product/etc/lowi.conf $MODPATH/system/my_product/etc/lowi.conf
cp_ch /my_product/etc/sap.conf $MODPATH/system/my_product/etc/sap.conf
cp_ch /my_product/etc/xtwifi.conf $MODPATH/system/my_product/etc/xtwifi.conf

if $KSU || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "delta" ] || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "kitsune" ]; then
rm -rf $MODPATH/post-fs-data.sh
rm -rf $MODPATH/system/my_product
rm -rf $MODPATH/system/vendor/odm
fi

settings put global assisted_gps_enabled 1
settings put global enable_gnss_raw_meas_full_tracking 0


ui_print "*          ->[Preparing! Please Wait!]<-          *"
ui_print "***************************************************"
ui_print "***************************************************"


  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$GCFG $CFG
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i 's/#NTRIP_CLIENT_LIB_NAME/NTRIP_CLIENT_LIB_NAME/g' $CFG
	sed -i 's/#PROXY_APP_PACKAGE_NAME/PROXY_APP_PACKAGE_NAME/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL = 1/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL = 2/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL = 3/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL = 4/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL = 5/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL=1/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL=2/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL=3/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL=4/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/IZAT_DEBUG_LEVEL=5/IZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 1/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 2/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 3/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 4/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 5/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL = 100/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=1/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=2/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=3/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=4/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=5/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/LOWI_LOG_LEVEL=100/LOWI_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 1/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 2/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 3/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 4/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 5/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = ALL/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=1/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=2/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=3/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=4/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=5/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL=ALL/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 1/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 2/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 3/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 4/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL = 5/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=1/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=2/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=3/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=4/DEBUG_LEVEL = 0/g' $CFG
	sed -i 's/DEBUG_LEVEL=5/DEBUG_LEVEL = 0/g' $CFG
	sed -i '/QXDM_LOG/d;s/^DEBUG_LEVEL = 0$/QXDM_LOG = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/BUFFER_DIAG_LOGGING/d;s/^DEBUG_LEVEL = 0$/BUFFER_DIAG_LOGGING = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/LOG_BUFFER_ENABLED/d;s/^DEBUG_LEVEL = 0$/LOG_BUFFER_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SGLTE_TARGET/d;s/^DEBUG_LEVEL = 0$/SGLTE_TARGET=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NMEA_TAG_BLOCK_GROUPING_ENABLED/d;s/^DEBUG_LEVEL = 0$/NMEA_TAG_BLOCK_GROUPING_ENABLED = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/GNSS_DEPLOYMENT/d;s/^DEBUG_LEVEL = 0$/GNSS_DEPLOYMENT = 2\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CUSTOM_NMEA_GGA_FIX_QUALITY_ENABLED/d;s/^DEBUG_LEVEL = 0$/CUSTOM_NMEA_GGA_FIX_QUALITY_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CID_DEFAULT_PROFILE/d;s/^DEBUG_LEVEL = 0$/CID_DEFAULT_PROFILE = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/CP_MTLR_ES/d;s/^DEBUG_LEVEL = 0$/CP_MTLR_ES=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/AGPS_CONFIG_INJECT/d;s/^DEBUG_LEVEL = 0$/AGPS_CONFIG_INJECT = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENABLE_PSDS_PERIODIC_DOWNLOAD/d;s/^DEBUG_LEVEL = 0$/ENABLE_PSDS_PERIODIC_DOWNLOAD=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/POSITION_ASSISTED_CLOCK_ESTIMATOR_ENABLED/d;s/^DEBUG_LEVEL = 0$/POSITION_ASSISTED_CLOCK_ESTIMATOR_ENABLED = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SET_ROAMING/d;s/^DEBUG_LEVEL = 0$/SET_ROAMING = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_TEST_ENABLED/d;s/^DEBUG_LEVEL = 0$/XTRA_TEST_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_VERSION_CHECK/d;s/^DEBUG_LEVEL = 0$/XTRA_VERSION_CHECK = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_THROTTLE_ENABLED/d;s/^DEBUG_LEVEL = 0$/XTRA_THROTTLE_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_SYSTEM_TIME_INJECT/d;s/^DEBUG_LEVEL = 0$/XTRA_SYSTEM_TIME_INJECT = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/XTRA_SOCK_KEEPALIVE/d;s/^DEBUG_LEVEL = 0$/XTRA_SOCK_KEEPALIVE = 1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENABLE_WIPER/d;s/^DEBUG_LEVEL = 0$/ENABLE_WIPER=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DEFAULT_AGPS_ENABLE/d;s/^DEBUG_LEVEL = 0$/DEFAULT_AGPS_ENABLE=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DEFAULT_USER_PLANE/d;s/^DEBUG_LEVEL = 0$/DEFAULT_USER_PLANE=true\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ACCURACY_THRES/d;s/^DEBUG_LEVEL = 0$/ACCURACY_THRES=0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/DR_SYNC_ENABLED/d;s/^DEBUG_LEVEL = 0$/DR_SYNC_ENABLED = 0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/INTERNET_IP_TYPE/d;s/^DEBUG_LEVEL = 0$/INTERNET_IP_TYPE = 2\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_IP_TYPE/d;s/^DEBUG_LEVEL = 0$/SUPL_IP_TYPE = 2\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_ES/d;s/^DEBUG_LEVEL = 0$/SUPL_ES=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL/d;s/^DEBUG_LEVEL = 0$/USE_EMERGENCY_PDN_FOR_EMERGENCY_SUPL=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/REPORT_POSTION_USE_SUPL_REFLOC/d;s/^DEBUG_LEVEL = 0$/REPORT_POSTION_USE_SUPL_REFLOC=1\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/SUPL_MODE/d' $CFG
	sed -i '/SUPL_HOST/d' $CFG
	sed -i '/SUPL_PORT/d' $CFG
	sed -i '/MO_SUPL_HOST/d' $CFG
	sed -i '/MO_SUPL_PORT/d' $CFG
	sed -i '/SUPL_TLS_HOST/d' $CFG
	sed -i '/SUPL_SECURE_PORT/d' $CFG
	sed -i '/SUPL_NO_SECURE_PORT/d' $CFG
	sed -i '/SUPL_TLS_CERT/d' $CFG
	sed -i '/C2K/d' $CFG
	sed -i '/CAPABILITIES/d' $CFG
	sed -i '/LPPE_CP_TECHNOLOGY/d;s/^DEBUG_LEVEL = 0$/LPPE_CP_TECHNOLOGY=0x2\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/LPPE_UP_TECHNOLOGY/d;s/^DEBUG_LEVEL = 0$/LPPE_UP_TECHNOLOGY=0x2\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/ENGINEHUB_TIMER_OFFSET_MSEC/d;s/^DEBUG_LEVEL = 0$/#ENGINEHUB_TIMER_OFFSET_MSEC=0\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/EHUB_AGGREGATOR_POSITION_AGE_MSEC/d;s/^DEBUG_LEVEL = 0$/#EHUB_AGGREGATOR_POSITION_AGE_MSEC=0\nDEBUG_LEVEL = 0/g' $CFG
	#IZAT_CONF
	# sed -i '/LPPE_SRN_DATA_SCAN_INJECT_TIME/d;s/^IZAT_DEBUG_LEVEL = 0$/#LPPE_SRN_DATA_SCAN_INJECT_TIME=0\nIZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i '/GEOFENCE_SERVICES_RESPONSIVENESS_OVERRIDE/d;s/^IZAT_DEBUG_LEVEL = 0$/GEOFENCE_SERVICES_RESPONSIVENESS_OVERRIDE = 3\nIZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i '/GTP_MODE/d;s/^IZAT_DEBUG_LEVEL = 0$/GTP_MODE=SDK\nIZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i '/SAP=/d;s/^IZAT_DEBUG_LEVEL = 0$/SAP=PREMIUM_ENV_AIDING\nIZAT_DEBUG_LEVEL = 0/g' $CFG
	sed -i '/USE_ZPP_IN_DBH/d;s/^IZAT_DEBUG_LEVEL = 0$/USE_ZPP_IN_DBH = 0\nIZAT_DEBUG_LEVEL = 0/g' $CFG
	# sed -i 's/PREMIUM_FEATURE=0/PREMIUM_FEATURE=1/g' $CFG
	sed -i 's/LOW_RAM_TARGETS=ENABLED/LOW_RAM_TARGETS=DISABLED/g' $CFG
	sed -i 's/PROCESS_STATE=DISABLED/PROCESS_STATE=ENABLED/g' $CFG
	#FLP_CONF
	sed -i 's/ACCURACY=0/ACCURACY=2/g' $CFG
	sed -i 's/ACCURACY=1/ACCURACY=2/g' $CFG
	sed -i 's/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 0/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 3/g' $CFG
	sed -i 's/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 1/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 3/g' $CFG
	sed -i 's/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 2/FLP_GEOFENCE_RESPONSIVENESS_OVERRIDE = 3/g' $CFG
	sed -i 's/ALLOW_NETWORK_FIXES = 0/ALLOW_NETWORK_FIXES = 1/g' $CFG
	#LOWI_CONF
	sed -i '/LOWI_USE_LOWI_LP/d;s/^LOWI_LOG_LEVEL = 0$/LOWI_USE_LOWI_LP = 1\nLOWI_LOG_LEVEL = 0/g' $CFG
	#XTWIFI_CONF
	sed -i '/GTP_AP_MODE/d;s/^DEBUG_GLOBAL_LOG_LEVEL = 0$/GTP_AP_MODE = 4\nDEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i '/GTP_AP_NEEDED_BY_MP_CELL/d;s/^DEBUG_GLOBAL_LOG_LEVEL = 0$/GTP_AP_NEEDED_BY_MP_CELL = 1\nDEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

  for GCFG2 in ${GPSCFG2}; do
	CFG2="$MODPATH$(echo $GCFG2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$GCFG2 $CFG2
	sed -i 's/\t/  /g' $CFG2
	sed -i 's/DEBUG_LEVEL = 1/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL = 2/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL = 3/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL = 4/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL = 5/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL=1/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL=2/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL=3/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL=4/DEBUG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_LEVEL=5/DEBUG_LEVEL = 0/g' $CFG2
	sed -i '/SENSOR_CONTROL_MODE/d;s/^DEBUG_LEVEL = 0$/SENSOR_CONTROL_MODE=0\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/NDK_PROVIDER_TIME_SOURCE/d;s/^DEBUG_LEVEL = 0$/NDK_PROVIDER_TIME_SOURCE=3\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/COUNT_BASED_BATCHING/d;s/^DEBUG_LEVEL = 0$/COUNT_BASED_BATCHING=2\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/LOCTECH_SLIM_ENABLE_SENSORHALDAEMON_PROVIDER/d;s/^DEBUG_LEVEL = 0$/LOCTECH_SLIM_ENABLE_SENSORHALDAEMON_PROVIDER=1\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/VN_DATA_TIMESTAMP_SRC/d;s/^DEBUG_LEVEL = 0$/VN_DATA_TIMESTAMP_SRC=0\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/SENSOR_USAGE/d;s/^DEBUG_LEVEL = 0$/SENSOR_USAGE=1\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/SENSOR_PROVIDER/d;s/^DEBUG_LEVEL = 0$/SENSOR_PROVIDER=1\nDEBUG_LEVEL = 0/g' $CFG2
	sed -i '/^ *#/d; /^ *$/d' $CFG2
	done

ui_print "*             Select NTP time server              *"
ui_print "***************************************************"
ui_print "* [Vol Up = Russia      |      Vol Down = Global] *"
ui_print "***************************************************"

if $VKSEL; then

ui_print "*           ->[Select Russian Server]<-            *"
ui_print "***************************************************"
settings put global ntp_server ntp1.vniiftri.ru
settings put global ntp_server_2 ntp2.vniiftri.ru
settings put global ntp_server_3 ntp3.vniiftri.ru
settings put global ntp_server_4 ntp4.vniiftri.ru
  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=ru.pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_2=ntp2.vniiftri.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_3=ntp3.vniiftri.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_4=ntp4.vniiftri.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_10/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_5=ntp.msk-ix.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_11/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_6=time.yandex.ru\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_12/d;s/^NTP_SERVER=ru.pool.ntp.org$/NTP_SERVER_7=ntp0.ntp-servers.net\nNTP_SERVER=ru.pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=ntp2.vniiftri.ru$/NTP_SERVER=ntp1.vniiftri.ru\nNTP_SERVER_2=ntp2.vniiftri.ru/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

else

ui_print "*           ->[Select Global Server]<-            *"
ui_print "***************************************************"
cp_ch $MODPATH/common/non-ru.prop $MODPATH/system.prop
cp_ch $MODPATH/common/service-non-ru.sh $MODPATH/service.sh
settings put global ntp_server 0.pool.ntp.org
settings put global ntp_server_2 1.pool.ntp.org
settings put global ntp_server_3 2.pool.ntp.org
settings put global ntp_server_4 3.pool.ntp.org
  for GCFG in ${GPSCFG}; do
	CFG="$MODPATH$(echo $GCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/NTP_SERVER/d;s/^DEBUG_LEVEL = 0$/NTP_SERVER=pool.ntp.org\nDEBUG_LEVEL = 0/g' $CFG
	sed -i '/NTP_SERVER_2/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_2=1.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_3/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_3=2.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER_4/d;s/^NTP_SERVER=pool.ntp.org$/NTP_SERVER_4=3.pool.ntp.org\nNTP_SERVER=pool.ntp.org/g' $CFG
	sed -i '/NTP_SERVER=/d;s/^NTP_SERVER_2=1.pool.ntp.org$/NTP_SERVER=0.pool.ntp.org\nNTP_SERVER_2=1.pool.ntp.org/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

fi

ui_print "***************************************************"
ui_print " "

	rm -rf $MODPATH/tools
	rm -rf /data/system/package_cache/*/*
	rm -rf /data/resource-cache/*
	rm -rf /cache/*
	rm -rf /data/local/traces
	rm -rf /data/*/*battery*
	rm -rf /data/*/*charge*
	rm -rf /data/*/bsplog
	rm -rf /data/anr
	rm -rf /data/tombstones
	rm -rf /data/*/tombstones
	find $MODPATH -empty -type d -delete
