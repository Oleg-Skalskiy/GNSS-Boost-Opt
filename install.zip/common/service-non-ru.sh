#!/system/bin/sh

# Service controller script

settings put global assisted_gps_enabled 1
settings put global enable_gnss_raw_meas_full_tracking 0
settings put global ntp_server 0.pool.ntp.org
settings put global ntp_server_2 1.pool.ntp.org
settings put global ntp_server_3 2.pool.ntp.org
settings put global ntp_server_4 3.pool.ntp.org
